#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Sprite sprite;

float escalaX;
float escalaY;
float heightSky;
float widthSky;
float heightWindow;
float widthWindow;

int main()
{

    texture.loadFromFile("fondo.jpg");

    /* FONDO*/
        sprite.setTexture(texture);

    sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Fondo");

    heightSky = (float)texture.getSize().y;
    heightWindow = (float)App.getSize().y;
    widthSky = (float)texture.getSize().x;
    widthWindow = (float)App.getSize().x;
    escalaY = heightWindow / heightSky; escalaX = widthWindow / widthSky;

    sprite.setScale(escalaX, escalaY);


    while (App.isOpen())
    {


        /* Limpiamos la ventana*/
        App.clear();

        /*Dibujamos la escena*/ 
        App.draw(sprite);


        /*Mostramos la ventana*/ 
        App.display();
    }

    return 0;
}