#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Texture texture1;
Texture texture2;
Texture texture3;
Texture texture4;
Sprite sprite;
Sprite sprite1;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;
int main()
{

    texture.loadFromFile("rcircle.png");
    texture1.loadFromFile("rcircle.png");
    texture2.loadFromFile("rcircle.png");
    texture3.loadFromFile("rcircle.png");
    texture4.loadFromFile("rcircle-modified.png");

    /*circulo0*/
    sprite.setTexture(texture);

    /*circulo1*/
    sprite1.setTexture(texture);
    sprite1.setPosition(800, 0);

    /*circulo2*/
    sprite2.setTexture(texture);
    sprite2.setPosition(0, 600);

    /*circulo3*/
    sprite3.setTexture(texture);
    sprite3.setPosition(800, 600);

    /*circulo4*/
    sprite4.setTexture(texture4);
    sprite4.setPosition(450, 400);

    sf::RenderWindow App(sf::VideoMode(900, 700, 32), "Transparencia");

    /*Para esta parte me ayud� con google y chat gpt*/

    sf::Vector2u windowSize = App.getSize();

    /*Tama�o de la imagen*/
    sf::Vector2u imageSize = texture4.getSize();


    float xPos = (windowSize.x - imageSize.x) / 2;
    float yPos = (windowSize.y - imageSize.y) / 2;

    sprite4.setPosition(xPos, yPos);

    float scaleFactor = 0.5;
    sprite.scale(scaleFactor, scaleFactor);
    sprite1.scale(scaleFactor, scaleFactor);
    sprite2.scale(scaleFactor, scaleFactor);
    sprite3.scale(scaleFactor, scaleFactor);
    /*hasta aqui*/
    while (App.isOpen())
    {


        /*Limpiamos la ventana*/ 
        App.clear();

        /* Dibujamos la escena*/
        App.draw(sprite);
        App.draw(sprite1);
        App.draw(sprite2);
        App.draw(sprite3);
        App.draw(sprite4);

        /* Mostramos la ventana*/
        App.display();
    }

    return 0;
}



/*no estoy segura si est� logrado el ejercicio, en google indicaba como colocar en cada esquina exacta el punto rojo
pero aun no vimos ese contenido en la asignatura. Igualmente lo dejo ac� abajo comentado para que me indiquen de ser posible
si esa es la forma correcta o hay mejores.


Obtenido el tama�o de la ventana y el de la imagen de referencia el c�lculo que se indica como correcto es:
   float scaleFactor = std::min(static_cast<float>(windowSize.x) / imageSize.x, static_cast<float>(windowSize.y) / imageSize.y);
    sprite.scale(scaleFactor, scaleFactor);

    // Colocar cada imagen en una esquina
    sprite.setPosition(0, 0); // Esquina superior izquierda
    sf::Sprite sprite1(sprite);
    sprite1.setPosition(windowSize.x - imageSize.x * scaleFactor, 0); // Esquina superior derecha
    sf::Sprite sprite2(sprite);
    sprite2.setPosition(0, windowSize.y - imageSize.y * scaleFactor); // Esquina inferior izquierda
    sf::Sprite sprite3(sprite);
    sprite3.setPosition(windowSize.x - imageSize.x * scaleFactor, windowSize.y - imageSize.y * scaleFactor); // Esquina inferior derecha
*/