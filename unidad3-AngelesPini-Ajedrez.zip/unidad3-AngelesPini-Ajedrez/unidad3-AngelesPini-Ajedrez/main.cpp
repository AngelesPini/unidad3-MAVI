#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Texture texture1;
Sprite sprite;
Sprite sprite1;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;
Sprite sprite5;
Sprite sprite6;
Sprite sprite7;
Sprite sprite8;
Sprite sprite9;
Sprite sprite10;
Sprite sprite11;
int main()
{

    texture.loadFromFile("chessb.png");
    texture1.loadFromFile("chessw.png");

    /*cuadro0*/
    sprite.setTexture(texture);

    /*cuadro1*/
    sprite1.setTexture(texture1);
    sprite1.setPosition(128, 0);

    /*cuadro2*/
    sprite2.setTexture(texture);
    sprite2.setPosition(256, 0);

    /*cuadro3*/
    sprite3.setTexture(texture1);
    sprite3.setPosition(384, 0);

    /*cuadro4*/
    sprite4.setTexture(texture);
    sprite4.setPosition(512, 0);

    /*cuadro5*/
    sprite5.setTexture(texture1);
    sprite5.setPosition(640, 0);

    /*cuadro6*/
    sprite6.setTexture(texture1);
    sprite6.setPosition(0, 128);

    /*cuadro7*/
    sprite7.setTexture(texture);
    sprite7.setPosition(128, 128);

    /*cuadro8*/
    sprite8.setTexture(texture1);
    sprite8.setPosition(256, 128);

    /*cuadro9*/
    sprite9.setTexture(texture);
    sprite9.setPosition(384, 128);

    /*cuadro10*/
    sprite10.setTexture(texture1);
    sprite10.setPosition(512, 128);
    /*cuadro10*/
    sprite11.setTexture(texture);
    sprite11.setPosition(640, 128);




    sf::RenderWindow App(sf::VideoMode(800, 800, 32), "Tablero");


    while (App.isOpen())
    {


        /*Limpiamos la ventana*/ 
        App.clear();

        /*Dibujamos la escena*/ 
        App.draw(sprite);
        App.draw(sprite1);
        App.draw(sprite2);
        App.draw(sprite3);
        App.draw(sprite4);
        App.draw(sprite5);
        App.draw(sprite6);
        App.draw(sprite7);
        App.draw(sprite8);
        App.draw(sprite9);
        App.draw(sprite10);
        App.draw(sprite11);

        /*Mostramos la ventana /*/
        App.display();
    }

    return 0;
}


/*En este punto, cuando llegu� al casillero nro 11, pens� que ser�a muy trabajoso hacer cada cuadro sprite por sprite. Creo que el dibujo del tablero quiz�s podria resolverse de alguna manera con un ciclo estilo for, un arreglo o matriz, un elemento div, o algun otro sistema que aun no conocemos.
Asi como pude reutilizar las variables �texture�, probablemente se puedan "reutilizar" los sprites.*/