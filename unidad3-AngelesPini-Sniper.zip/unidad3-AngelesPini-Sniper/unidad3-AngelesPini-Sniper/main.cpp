#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Texture texture1;
Texture texture2;
Texture texture3;
Sprite sprite;
Sprite sprite1;
Sprite sprite2;
Sprite sprite3;
int main()
{

    texture.loadFromFile("rcircle.png");
    texture1.loadFromFile("rcircle.png");
    texture2.loadFromFile("rcircle.png");
    texture3.loadFromFile("rcircle.png");

    /*circulo0*/
    sprite.setTexture(texture);

    /*circulo1*/
    sprite1.setTexture(texture1);
    sprite1.setPosition(800, 0);

    /*circulo2*/
    sprite2.setTexture(texture2);
    sprite2.setPosition(0, 600);

    /*circulo3*/
    sprite3.setTexture(texture1);
    sprite3.setPosition(800, 600);

    sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Puntos rojos");


    while (App.isOpen())
    {


        /*Limpiamos la ventana*/
        App.clear();

        /*Dibujamos la escena*/
        App.draw(sprite);
        App.draw(sprite1);
        App.draw(sprite2);
        App.draw(sprite3);

        /* Mostramos la ventana*/
        App.display();
    }

    return 0;
}


/*Intent� escalar los puntos pero con la info del apunte no logr� hacerlo, ya que para el ejemplo se toma de referencia el tama�o de una imagen ya existente. Siendo �ste el caso de 4 imagenes iguales, no lo logr�.
Las coordenadas 800 y 600 me quitan de la vista los 4 puntos de referencia; Si dismiinuyo el numero de coordenadas de  visualizan sin problemas. 
Espero sea correcto, comprendo el concepto pero quiz�s me faltan herramientas o repaso del material para lograr el resultado deseado*/