#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Sprite sprite;


int main()
{

    texture.loadFromFile("cuad_blue.png");

    /*FONDO*/
    sprite.setTexture(texture);


    // Establecer el origen del sprite en su centro para que rote alrededor de su centro
    sprite.setOrigin(sprite.getLocalBounds().width / 2, sprite.getLocalBounds().height / 2);

    // Posici�n inicial del sprite
    sprite.setPosition(400, 300);

    Clock clock;


    sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Rotacion");



    while (App.isOpen())
    {
        Event event;
        while (App.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                App.close();
            }
        }

        float angle = clock.getElapsedTime().asSeconds() * 60;

        sprite.setRotation(angle);

        // Limpiamos la ventana
        App.clear();

        // Dibujamos la escena
        App.draw(sprite);


        // Mostramos la ventana
        App.display();
    }

    return 0;
}