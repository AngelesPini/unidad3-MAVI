#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Sprite sprite;
Sprite sprite1;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;


float heightWindow;
float widthWindow;

int main()
{

    texture.loadFromFile("plataforma.jpg");

    /*plataforma*/
    sprite.setTexture(texture);
    sprite1.setTexture(texture);
    sprite2.setTexture(texture);
    sprite3.setTexture(texture);
    sprite4.setTexture(texture);


    sprite.setScale(.2, .5);
    sprite1.setScale(.2, .8);
    sprite2.setScale(.2, 1.1);
    sprite3.setScale(.2, 1.4);
    sprite4.setScale(1.7, .2);



    sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Plataforma");
    heightWindow = (float)App.getSize().y;
    widthWindow = (float)App.getSize().x;

    sprite.setPosition(0, 375);
    sprite1.setPosition(widthWindow-700, 300);
    sprite2.setPosition(widthWindow - 600, 225);
    sprite3.setPosition(widthWindow - 500, 150);
    sprite4.setPosition(widthWindow - 400, 150);


    /*hasta aqui*/

    while (App.isOpen())
    {

        // Limpiamos la ventana
        App.clear();

        // Dibujamos la escena
        App.draw(sprite);
        App.draw(sprite1);
        App.draw(sprite2);
        App.draw(sprite3);
        App.draw(sprite4);


        // Mostramos la ventana
        App.display();
    }

    return 0;
}


/*creo que pude resolverlo bastante bien conforme al modelo y el contenido aprendido. Estoy especialmente feliz con este ejercicio*/