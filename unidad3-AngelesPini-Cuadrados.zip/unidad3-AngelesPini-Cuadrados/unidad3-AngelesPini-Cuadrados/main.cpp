#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Texture texture1;
Texture texture2;
Texture texture3;
Sprite sprite;
Sprite sprite1;
Sprite sprite2;
Sprite sprite3;


/*Medidas*/
float escalaX1;
float escalaY1;
float escalaX2;
float escalaY2;
float escalaX3;
float escalaY3;
float heightCuad1;
float widthCuad1;
float heightCuad2;
float widthCuad2;
float heightCuad3;
float widthCuad3;
float heightRef;
float widthRef;

int main()
{

    texture.loadFromFile("cuad_red.png");
    texture1.loadFromFile("cuad_yellow.png");
    texture2.loadFromFile("cuad_blue.png");
    texture3.loadFromFile("cuad_grey.png");

    /*cuadrados*/
    sprite.setTexture(texture);
    sprite1.setTexture(texture1);
    sprite2.setTexture(texture2);
    sprite3.setTexture(texture3);

    sf::RenderWindow App(sf::VideoMode(800, 800, 32), "Cuadrados");

    /*sprite1*/
    heightCuad1 = (float)texture1.getSize().y;
    heightRef = (float)texture.getSize().y;
    widthCuad1 = (float)texture1.getSize().x;
    widthRef = (float)texture.getSize().x;
    escalaY1 = heightRef / heightCuad1; escalaX1 = widthRef / widthCuad1;


    sprite1.setScale(escalaX1, escalaY1);
    sprite1.setPosition(widthRef,0 );

    /*sprite2*/
    heightCuad2 = (float)texture2.getSize().y;
    widthCuad2 = (float)texture2.getSize().x;
    escalaY2 = heightRef / heightCuad2; escalaX2 = widthRef / widthCuad2;

    sprite2.setScale(escalaX2, escalaY2);
    sprite2.setPosition(0, heightRef);

    /*sprite3*/
    heightCuad3 = (float)texture3.getSize().y;
    widthCuad3 = (float)texture3.getSize().x;
    escalaY3 = heightRef / heightCuad3; escalaX3 = widthRef / widthCuad3;

    sprite3.setScale(escalaX3, escalaY3);
    sprite3.setPosition(widthRef, heightRef);


    while (App.isOpen())
    {


        /* Limpiamos la ventana*/
        App.clear();

        /*Dibujamos la escena*/ 
        App.draw(sprite);
        App.draw(sprite1);
        App.draw(sprite2);
        App.draw(sprite3);

        /* Mostramos la ventana*/
        App.display();
    }

    return 0;
}
/*me cost� un poco pero pude resolverlo en 45 minutos aproximadamente.
Al igual que en el tablero de ajedrez, asumo que colocanto las referencias una funcion y recibiendo como par�metro 
a cada sprite en el llamado a la funcion podria optimizarse mas el codigo. Sin embargo no logre hacerlo de esa manera
y lo resolv� como en los apuntes.*/